# Hem - FHIR-utbildning – Kurs-IG (facit) v0.1.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/education/kursig/ImplementationGuide/fhir.education.kursig | *Version*:0.1.0 |
| Draft as of 2026-10-29 | *Computable Name*:FhirEducationKursIG |

Det här är den Implementation Guide (IG) som vi bygger upp under FHIR-utbildningen.

Den byggs automatiskt med **SUSHI** och **IG Publisher** av GitHub Actions varje gång du checkar in en ändring under `test-ig/`. Resultatet publiceras på repots GitHub Pages-sida.

### Innehåll

Startläget innehåller en enda profil, [EducationPatient](StructureDefinition-EducationPatient.md), och ett exempel på en patient som följer profilen. Under kursen bygger vi vidare med:

| | |
| :--- | :--- |
| 3 – FSH | Profilen`EducationEncounter`, terminologibindningar, en egen extension och slicing av`identifier` |
| 4 – FHIRPath | Egna invarianter (constraints) på Patient och Encounter |
| 6 – Följsamhet | Ett CapabilityStatement som beskriver krav på en server |

Se alla artefakter under [Artefakter](artifacts.md). Kvalitetsrapporten från IG Publisher finns i [qa.html](qa.md).

Denna publication inkluderar IP som omfattas av följande uttalanden.

* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [ActCode](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ActCode.html): [EducationEncounter](StructureDefinition-EducationEncounter.md), [EducationEncounterClassVS](ValueSet-education-encounter-class.md) and [Encounter/encounter-tolvan-1](Encounter-encounter-tolvan-1.md)
* [MaritalStatus](http://terminology.hl7.org/7.5.0/CodeSystem-v3-MaritalStatus.html): [EducationPatient](StructureDefinition-EducationPatient.md) and [Patient/patient-tolvan](Patient-patient-tolvan.md)
* [NullFlavor](http://terminology.hl7.org/7.5.0/CodeSystem-v3-NullFlavor.html): [EducationPatient](StructureDefinition-EducationPatient.md)


Detta är en R4 IG. Inga av funktionerna den använder har ändrats i R4B, så den kan användas som den är med R4B-system. Paket för både [R4 (fhir.education.kursig.r4)](package.r4.tgz) och [R4B (fhir.education.kursig.r4b)](package.r4b.tgz) är tillgängliga.



*There are no Global profiles defined*

